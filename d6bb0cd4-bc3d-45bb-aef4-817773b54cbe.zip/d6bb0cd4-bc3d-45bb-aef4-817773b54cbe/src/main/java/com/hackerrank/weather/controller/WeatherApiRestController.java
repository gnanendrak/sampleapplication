package com.hackerrank.weather.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.weather.model.Weather;
import com.hackerrank.weather.repository.WeatherRepository;

@RestController
public class WeatherApiRestController {

	@Autowired
	private WeatherRepository weatherRepository;

	@DeleteMapping("/erase")
	public void eraseWeather(@RequestParam Date start, @RequestParam Date end, @RequestParam Float lat,
			@RequestParam Float lon) {

		if (start != null && end != null && lat != null && lon != null)
			weatherRepository.deleteByCriteria(start, end, lat, lon);
		else
			weatherRepository.deleteAll();

	}

	@PostMapping("/Weather")
	public ResponseEntity createWeather(@RequestBody Weather weather) {
		Weather weatherDB = weatherRepository.findById(weather.getId());
		if (weatherDB != null) {
			return new ResponseEntity(HttpStatus.BAD_REQUEST);
		} else {
			weatherRepository.save(weather);
			return new ResponseEntity(HttpStatus.CREATED);
		}

	}

	@GetMapping("/Weather")
	public ResponseEntity getWeather(@RequestParam Float lat, @RequestParam Float lon) {
		if (lat != null && lon != null) {
			List<Weather> allWeather = weatherRepository.findByCriteria(lat, lon);
			if (CollectionUtils.isEmpty(allWeather)) {
				return new ResponseEntity(HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity(allWeather, HttpStatus.OK);
			}

		} else {
			Sort sort = new Sort(Sort.Direction.ASC, "id");
			return new ResponseEntity(weatherRepository.findAll(sort), HttpStatus.OK);
		}

	}

}
