package com.hackerrank.weather.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hackerrank.weather.model.Weather;

@Repository
public interface WeatherRepository extends JpaRepository<Weather, Long>{
	
	@Query("DELETE FROM Weather w where w.location.latitude = :lat and w.location.longitude = :lon and dateRecorded between :start and :end")
	public void deleteByCriteria(Date start, Date end, Float lat, Float lon);
	
	public Weather findById(Long id);

	@Query("SELECT w FROM Weather w where w.location.latitude = :lat and w.location.longitude = :lon order by w.id")
	public List<Weather> findByCriteria(Float lat, Float lon);
	
}
