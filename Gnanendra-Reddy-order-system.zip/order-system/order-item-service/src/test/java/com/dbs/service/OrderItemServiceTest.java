package com.dbs.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.dbs.model.OrderItem;
import com.dbs.repository.OrderItemRepository;

@SpringBootTest
class OrderItemServiceTest {

	@InjectMocks
	private OrderItemService orderItemService;

	@Mock
	private OrderItemRepository orderItemRepository;

	@Before(value = "")
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testSaveOrderItem() {

		List<OrderItem> orderItemList = new  ArrayList<>();
		orderItemList.add(new OrderItem("ACGSB674CF", 1, "product_1", 1));
		when(orderItemRepository.saveAll(orderItemList)).thenReturn(orderItemList);

		assertEquals(orderItemList.get(0).getProductName(),orderItemService.saveOrderItems(orderItemList).get(0).getProductName());
	}

	@Test
	void testGetItemsByOrderReference() {

		String orderReference = "RFE235SB674CF";

		when(orderItemRepository.getItemsByOrderReference(orderReference))
				.thenReturn(Stream.of(new OrderItem("RFE235SB674CF", 1, "product_1", 1)).collect(Collectors.toList()));

		assertEquals(orderReference ,orderItemService.getItemsByOrderReference(orderReference).get(0).getOrderItemReference());
	}

}
