package com.dbs.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.dbs.model.OrderItem;
import com.dbs.service.OrderItemService;

@SpringBootTest
class OrderItemControllerTest {
	
	@InjectMocks
	private OrderItemController orderItemController;
	
	@Mock
	private OrderItemService orderItemService;
	
	@Before(value = "")
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testNewOrderItem() {
		
		List<OrderItem> orderItemList = new  ArrayList<>();
		orderItemList.add(new OrderItem("ACGSB674CF", 1, "product_1", 1));
		when(orderItemService.saveOrderItems(orderItemList)).thenReturn(orderItemList);
		
		assertEquals(orderItemList.get(0).getProductCode(), orderItemController.newOrderItem(orderItemList).get(0).getProductCode());

	}

	@Test
	void testGetItemsByOrderReference() {
		
		String orderReference = "RFE235SB674CF";

		when(orderItemService.getItemsByOrderReference(orderReference))
				.thenReturn(Stream.of(
						new OrderItem("RFE235SB674CF", 2, "product_2", 1),
						new OrderItem("RFE235SB674CF", 5, "product_5", 8)
						).collect(Collectors.toList()));

		assertEquals(orderReference ,orderItemController.getItemsByOrderReference(orderReference).get(0).getOrderItemReference());
	}

}
