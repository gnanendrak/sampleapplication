package com.dbs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.model.OrderItem;
import com.dbs.repository.OrderItemRepository;

@Service
public class OrderItemService {
	
	@Autowired
	private OrderItemRepository orderItemRepository;

	public List<OrderItem> saveOrderItems(List<OrderItem> orderItem) {
		
		return orderItemRepository.saveAll(orderItem);
	}

	public List<OrderItem> getItemsByOrderReference(String orderReference) {
		
		return orderItemRepository.getItemsByOrderReference(orderReference);
	}

}
