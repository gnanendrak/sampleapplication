package com.dbs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T_Order_Item")
public class OrderItem {
	
	@Id
    @GeneratedValue
    @Column(name = "id")
	private Integer id;
	
	private String orderItemReference;
	private int productCode;
	private String productName;
	private int quantity;
	
	public OrderItem() {}
	
	public OrderItem(String orderItemReference, int productCode, String productName, int quantity) {
		super();
		this.orderItemReference = orderItemReference;
		this.productCode = productCode;
		this.productName = productName;
		this.quantity = quantity;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderItemReference() {
		return orderItemReference;
	}
	public void setOrderItemReference(String orderItemReference) {
		this.orderItemReference = orderItemReference;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", orderItemReference=" + orderItemReference + ", productCode=" + productCode
				+ ", productName=" + productName + ", quantity=" + quantity + "]";
	}

}
