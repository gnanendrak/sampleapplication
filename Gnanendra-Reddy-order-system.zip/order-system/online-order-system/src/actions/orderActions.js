import { CREATE_ORDER, CLEAR_CART, CLEAR_ORDER, FETCH_ORDERS } from "../types";

export const createOrder = (order) => (dispatch) => {

  const orderItems = order.cartItems.map( item => {
    return {
      productCode: item.productCode,
      productName: item.productName,
      quantity: item.count
    }
  })
  const requestData = {

    customerName: order.name,
    shippingAddress: order.address,
    orderDate:"31082020",
    total: order.total,
    orderItem: orderItems
  }

  fetch("http://localhost:8081/api/order", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(requestData),
  })
    .then((res) => res.json())
    .then((data) => {
      dispatch({ type: CREATE_ORDER, payload: data });
      localStorage.clear("cartItems");
      dispatch({ type: CLEAR_CART });
    });
};
export const clearOrder = () => (dispatch) => {
  dispatch({ type: CLEAR_ORDER });
};
export const fetchOrders = () => (dispatch) => {
  fetch("http://localhost:8081/api/order")
    .then((res) => res.json())
    .then((data) => {
      dispatch({ type: FETCH_ORDERS, payload: data });
    });
};
