import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchOrders } from "../actions/orderActions";
import formatCurrency from "../util";
import _ from 'lodash';


class Orders extends Component {
  componentDidMount() {
    this.props.fetchOrders();
  }
  render() {
    const { orders } = this.props;
    const test = [];
    return _.isEmpty(orders) ? (
      <div>No Orders Found</div>
    ) : (
      <div className="orders">
        <h2>Orders</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>DATE</th>
              <th>TOTAL</th>
              <th>NAME</th>
              <th>ADDRESS</th>
              <th>ITEMS</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr>
                <td>{order.orderItemsReference}</td>
                <td>{order.orderDate}</td>
                <td> {formatCurrency(order.total)}</td>
                <td>{order.customerName}</td>
                <td>{order.shippingAddress}</td>
                <td>
                  {order.orderItem.map((item) => (
                    <div>
                      {item.quantity} {" x "} {item.productName}
                    </div>
                  ))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
export default connect(
  (state) => ({
    orders: state.order.orders,
  }),
  {
    fetchOrders,
  }
)(Orders);
