import React, { Component } from "react";
import Orders from "../components/Orders";

export default class OrderInforScreen extends Component {
  render() {
    return (
      <div>
        <Orders />
      </div>
    );
  }
}
