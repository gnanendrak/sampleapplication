package com.dbs.model;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "T_Order")
public class Order {
	
	@Id
    @GeneratedValue
    @Column(name = "id")
	@JsonIgnore
	private Integer id;
	
	@NotEmpty(message = "Please provide customer name")
	private String customerName;
	private String orderDate;
	
	@NotEmpty(message = "Please provide shipping address")
	private String shippingAddress;
	
	private String orderItemsReference;
	
	@DecimalMin("1.00")
	private BigDecimal total;
	
	@Transient
	@NotEmpty(message = "Please choose order items")
	@Valid
	private List<OrderItem> orderItem;
	
	
	public Order() {}
	
	public Order(String customerName, String orderDate, String shippingAddress, String orderItemsReference, BigDecimal total, List<OrderItem> orderItem) {
		super();
		this.customerName = customerName;
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.orderItemsReference = orderItemsReference;
		this.total = total;
		this.orderItem = orderItem;
	}
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getOrderItemsReference() {
		return orderItemsReference;
	}
	public void setOrderItemsReference(String orderItemsReference) {
		this.orderItemsReference = orderItemsReference;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	
	public List<OrderItem> getOrderItem() {
		return orderItem;
	}
	public void setOrderItem(List<OrderItem> orderItem) {
		this.orderItem = orderItem;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", customerName=" + customerName + ", orderDate=" + orderDate + ", shippingAddress="
				+ shippingAddress + ", orderItemsReference=" + orderItemsReference + ", total=" + total + ", orderItem="
				+ orderItem + "]";
	}
	
}
