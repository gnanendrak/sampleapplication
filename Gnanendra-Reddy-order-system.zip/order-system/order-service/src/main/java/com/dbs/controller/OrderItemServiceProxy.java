package com.dbs.controller;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.dbs.model.OrderItem;

@FeignClient(name = "order-item-service")
public interface OrderItemServiceProxy {
	
	@PostMapping(path="/api/orderItem", produces = "application/json")
	List<OrderItem> newOrderItem(List<OrderItem> orderItem);
	
	@GetMapping(path="/api/orderItem/{orderReference}", produces = "application/json")
	List<OrderItem> getItemsByOrderReference(@PathVariable String orderReference);

}
