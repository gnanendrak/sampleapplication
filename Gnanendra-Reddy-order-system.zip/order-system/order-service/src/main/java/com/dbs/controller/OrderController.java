package com.dbs.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.exception.OrderNotFoundException;
import com.dbs.model.Order;
import com.dbs.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api")
@CrossOrigin
@Validated
public class OrderController {

	@Autowired
    private OrderService orderService;
	
	
    @PostMapping("/order")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Create new order",
    		notes = "Provide all info except Order items reference number",
    		response = Order.class)
    public Order newOrder(@Valid @RequestBody Order order) {
        return orderService.saveOrder(order);
    }
    
    @ApiOperation(value = "Return you all Orders",
    		notes = "",
    		response = Order.class)
    @GetMapping("/order")
    public List<Order> allOrders() {
    	
        return orderService.getAllOrders();
    }
    
    @ApiOperation(value = "Retuen Order based on Order Reference",
    		notes = "Provide Valid Order Reference",
    		response = Order.class)
    @GetMapping("/order/{id}")
    public Order getOrderByReference(@PathVariable String id) throws OrderNotFoundException {
    	
        return orderService.getOrderByReference(id).get();
    }
}
