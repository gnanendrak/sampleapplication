package com.dbs.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OpAnd;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dbs.controller.OrderItemServiceProxy;
import com.dbs.exception.OrderNotFoundException;
import com.dbs.model.Order;
import com.dbs.model.OrderItem;
import com.dbs.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private OrderItemServiceProxy orderItemServiceProxy;

	@Transactional
	public Order saveOrder(Order order) {
	     
	     DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	     
	     order.setOrderItemsReference( UUID.randomUUID().toString().replaceAll("-", "").toUpperCase());
	     order.setOrderDate(dateTimeFormatter.format(LocalDateTime.now()));
		
	     Order orderResponse = orderRepository.save(order);
	     
	     for(OrderItem orderItem: order.getOrderItem()) {
	    	 orderItem.setOrderItemReference(orderResponse.getOrderItemsReference());
	    	 
	     }
	      
	     orderItemServiceProxy.newOrderItem(order.getOrderItem());
	     
	    return orderResponse;
	}

	public List<Order> getAllOrders() {
		
		List<Order> orderList = orderRepository.findAll();
		
		for(Order order: orderList) {
			List<OrderItem> orderItemsList =  orderItemServiceProxy.getItemsByOrderReference(order.getOrderItemsReference());
			order.setOrderItem(orderItemsList);
		}
		
		return orderList;
	}
	
	public Optional<Order> getOrderByReference(String id) throws OrderNotFoundException {
		
		Optional<Order> order = orderRepository.findByReference(id);
		List<OrderItem> orderItems = new ArrayList<OrderItem>();
		
		if(order.isPresent()) {
			orderItems = orderItemServiceProxy.getItemsByOrderReference(order.get().getOrderItemsReference());
			order.get().setOrderItem(orderItems);
		}	
		else
			throw new OrderNotFoundException(id);
		
		return order;
	}

}
