package com.dbs.exception;

public class OrderNotFoundException  extends Exception{

	private static final long serialVersionUID = 1L;

	public OrderNotFoundException(String orderReference) {
        super("Order not found : " + orderReference);
    }
}
