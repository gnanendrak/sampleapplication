package com.dbs.model;

import javax.validation.constraints.NotEmpty;

public class OrderItem {
	
	private String orderItemReference;
	
	private Integer productCode;
	
	@NotEmpty(message = "Product Name Required")
	private String productName;
	
	private Integer quantity;
	
	public OrderItem() {}
	
	public OrderItem(String orderItemReference, int productCode, String productName, int quantity) {
		super();
		this.orderItemReference = orderItemReference;
		this.productCode = productCode;
		this.productName = productName;
		this.quantity = quantity;
	}
	
	public String getOrderItemReference() {
		return orderItemReference;
	}
	public void setOrderItemReference(String orderItemReference) {
		this.orderItemReference = orderItemReference;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "OrderItem [orderItemReference=" + orderItemReference + ", productCode=" + productCode + ", productName="
				+ productName + ", quantity=" + quantity + "]";
	}

}
