package com.dbs.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.dbs.model.Order;
import com.dbs.model.OrderItem;
import com.dbs.service.OrderService;

@SpringBootTest
class OrderControllerTest {
	
	@InjectMocks
	private OrderController OrderController;
	
	@Mock
	private OrderService orderService;
	
	@Before(value = "")
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	

	@Test
	void testNewOrder() {
		
		List<OrderItem> orderItemList = new  ArrayList<>();
		orderItemList.add(new OrderItem("ACGSB674CF", 1, "product_1", 1));
		
		Order oprder = new Order("Test_Name", "20092020", "Singapore", "ACGSB674CF", new BigDecimal(10.90), orderItemList);
		
		when(orderService.saveOrder(oprder)).thenReturn(oprder);
		
		assertEquals(oprder.getOrderItemsReference(), OrderController.newOrder(oprder).getOrderItemsReference());
	}

	@Test
	void testAllOrders() {
		
		List<OrderItem> orderItemList = new  ArrayList<>();
		orderItemList.add(new OrderItem("ACGSB674CF", 1, "product_1", 1));
		
		List<Order> orderList = new ArrayList<Order>();
		orderList.add(new Order("Test_Name", "20092020", "Singapore", "ACGSB674CF", new BigDecimal(10.90), orderItemList));
		
		when(orderService.getAllOrders()).thenReturn(orderList);
		
		assertEquals(orderList.size(), OrderController.allOrders().size());
	}

	@Test
	void testGetOrderByReference() {
		
		String orderRefertence = "ACGSB674CF";
		List<OrderItem> orderItemList = new  ArrayList<>();
		orderItemList.add(new OrderItem("ACGSB674CF", 1, "product_1", 1));
		
		Order order = new Order("Test_Name", "20092020", "Singapore", "ACGSB674CF", new BigDecimal(10.90), orderItemList);
		
	}

}
