Online Order System

	Online Order System is a simple e-commerce platform to place order items and view Order.

PRE REQUIREMENTS

	Any code editor
	NPM
	JAVA
	Spring Boot
	MAVEN
	Database
	Any browser
	
	
BUILD and RUN:

	1. discovery-server
		
		To build the executable Jar, run the following maven command in the project root directory
		 $ mvn clean package
	
		It will create a jar discovery-server-0.0.1-SNAPSHOT.jar in <Project Root Folder>/target directory.
		
		Go to <Project Root Folder> location and execute below command
 		 $ java -jar target/discovery-server-0.0.1-SNAPSHOT.jar
 		 
 	2. order-item-service 
		
		To build the executable Jar, run the following maven command in the project root directory
		 $ mvn clean package
	
		It will create a jar order-item-service 0.0.1-SNAPSHOT in <Project Root Folder>/target directory.
		
		Go to <Project Root Folder> location and execute below command
 		 $ java -jar target/order-item-service 0.0.1-SNAPSHOT
 		 
  	3. order-service 
		
		To build the executable Jar, run the following maven command in the project root directory
		 $ mvn clean package
	
		It will create a jar order-service 0.0.1-SNAPSHOT in <Project Root Folder>/target directory.
		
		Go to <Project Root Folder> location and execute below command
 		 $ java -jar target/order-service 0.0.1-SNAPSHOT
		
	 OR
 
 	  If you have Spring Tool Suite (STS) editor, right click on project and Run as Spring Boot App.
 	  
 	4. Run Front end application
 	   Go inside online-order-system folder and run below commands.
	   npm i	
 	   npm start
 	   
 
Application Flow
	Program run as follows

	1. Run Spring Boot microservices and front end application as explained in previous step
	2. Run front end react application and open http://localhost:3000/ in browser
	3. Choose items and place order.
	4. Once place order success you will successful message on screen.
	5. open new tab on browser and paste below url which opens H2 in memory.
		http://localhost:8081/h2-console/login.jsp (T_ORDER table will be created)
		http://localhost:8082/h2-console/login.jsp (T_ORDER_ITEM table will be created)
	6. Make sure under JDBC url schema will be added(orderMgmt is my schema name).
		Sample: jdbc:h2:mem:orderMgmt
	7. Enter User Name as sa and click connect.
	8. Once connected you can see respective tables.
	9. Query table to see output.
	10. To view all orders in UI click on View Order
	11. To view swagger documentation use below link
	    http://localhost:8081/swagger-ui.html#/
		
	
 